<?php
if(isset($_POST['submit'])){
include "../config/connect.php";
$name=mysqli_real_escape_string($conn,$_POST['name']);
$userid=mysqli_real_escape_string($conn,$_POST['userid']);
$email=mysqli_real_escape_string($conn,$_POST['email']);
$premise=mysqli_real_escape_string($conn,$_POST['premise']);
$password=mysqli_real_escape_string($conn,$_POST['password']);
if(trim($name)==NULL or trim($name)=="" or is_numeric($name)){
	$_SESSION['msg']="<font color='red'>Please enter correct value for name</font>";
	header("location:../register.php");
}
elseif(trim($email)==NULL or trim($email)=="" or is_numeric($email)){
	$_SESSION['msg']="<font color='red'>Please enter correct value for email</font>";
	header("location:../register.php");
}
elseif(trim($premise)==NULL or trim($premise)=="" or is_numeric($premise)){
$_SESSION['msg']="<font color='red'>Please select an appropriate premise type</font>";
header("location:../register.php");
}
elseif(trim($premise)=="other" or $premise=="other"){
$premise=mysqli_real_escape_string($conn,$_POST['premisetype']);
if(trim($premise)==NULL or trim($premise)=="" or is_numeric($premise)){
$_SESSION['msg']="<font color='red'>Please select an appropriate premise type</font>";
header("location:../register.php");
	}
}
elseif(trim($password)==NULL or trim($password)==""){
	$_SESSION['msg']="<font color='red'>Please enter value for pin</font>";
	header("location:../register.php");
}
else{
$abhisar="insert into tbl_user(name,userid,email,premises,pin) values('$name','$userid','$email','$premise','$password')";
$abhi=mysqli_query($conn,$abhisar) or die(mysqli_error($conn));
if($abhi){
	echo "<script>alert('Registered Successfully');</script>";
	echo "<script>window.location.href='../login.php';</script>";
}
else{
	echo "<script>alert('Could not Registered');</script>";
	echo "<script>window.location.href='../register.php';</script>";
}
}
}
?>
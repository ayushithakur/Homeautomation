<div class="left-aside desktop-view">
    <div class="aside-branding">
        <a href="index.php" class="iconic-logo"><img src="images/favicon-techno.ico" class="img-responsive" alt="Matmix Logo" style="width: 60px; padding: 13px;">
        </a>
        <a href="index.php" class="large-logo"><img src="images/logo.png" style="width:245px;height:60px;" class="img-responsive" alt="Matmix Logo">
        </a><span class="aside-pin waves-effect"><i class="fa fa-thumb-tack"></i></span>
        <span class="aside-close waves-effect"><i class="fa fa-times"></i></span>
    </div>
    <div class="left-navigation">
        <ul class="list-accordion">
            <li><a href="index.php" class="waves-effect"><span class="nav-icon"><i class="fa fa-home"></i></span><span class="nav-label">Dashboard</span> </a>
                
            </li>
			    <li><a href="addroom.php" class="waves-effect"><span class="nav-icon"><i class="fa fa-home"></i></span><span class="nav-label">Add Room</span> </a>
                
            </li>
			    <li><a href="adddevice.php" class="waves-effect"><span class="nav-icon"><i class="fa fa-home"></i></span><span class="nav-label">Add Device</span> </a>
                
            </li>
   
			
        </ul>
    </div>
</div>
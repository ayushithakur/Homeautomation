$(document).ready(function()
{
	$(".department").change(function()
	{
		var id=$(this).val();
		var dataString = 'id='+ id;
		$(".classes").find('option').remove();
		$.ajax
		({
			type: "POST",
			url: "get_class.php",
			data: dataString,
			cache: false,
			success: function(html)
			{
				$(".classes").html(html);
			} 
		});
	});
});
<!doctype html>
<html>

<!-- Mirrored from www.lab.westilian.com/matmix-admin/iconic-view/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 28 Sep 2017 07:47:17 GMT -->
<?php 
include_once 'head.php';
 ?>
<body>
<div class="page-container pin-it">
<!--Leftbar Start Here -->
<?php 
include_once 'sidebar.php';
 ?>
<div class="page-content">
<!--Topbar Start Here -->
<?php 
include_once 'header.php';
 ?>
<div class="main-container">
<div class="container-fluid">
<div class="page-breadcrumb">
    <div class="row">
        <div class="col-md-7">
            <div class="page-breadcrumb-wrap">

                <div class="page-breadcrumb-info">
                    <h2 class="breadcrumb-titles">Dashboard <small>Web Application Backend</small></h2>
                    <ul class="list-page-breadcrumb">
                        <li><a href="#">Home</a>
                        </li>
                        <li class="active-page"> Dashboard</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-5">
        </div>
    </div>
</div>
    <div class="row">
        <div class="col-md-3 col-sm-6">
            <div class="iconic-w-wrap number-rotate">
                <span class="stat-w-title">Total Users</span>
                <a href="#" class="ico-cirlce-widget w_bg_cyan">
                    <span><i class="ico-users"></i></span>
                </a>
                <div class="w-meta-info">
                    <span class="w-meta-value number-animate" data-value="330" data-animation-duration="1500">0</span>
                    <span class="w-meta-title">New Users</span>
                   <!-- <span class="w-previos-stat">Last Day : 210</span>-->
                </div>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="iconic-w-wrap iconic-w-wrap">
                <span class="stat-w-title">Total Devices</span>
                <a href="#" class="ico-cirlce-widget w_bg_grey">
                    <span><i class="fa fa-dashcube"></i></span>
                </a>
                <div class="w-meta-info">
                    <span class="w-meta-value number-animate" data-value="127" data-animation-duration="1500">0</span>
                    <span class="w-meta-title">New Devices</span>
                  <!--  <span class="w-previos-stat">Last Day : 110</span>-->
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="iconic-w-wrap iconic-w-wrap">
                <span class="stat-w-title">Your Devices</span>
                <a href="#" class="ico-cirlce-widget w_bg_blue_grey">
                    <span><i class="fa fa-fighter-jet"></i></span>
                </a>
                <div class="w-meta-info w-currency">
                    <span class="w-meta-value number-animate" data-value="6127" data-animation-duration="1500">0</span>
                    <span class="w-meta-title">Your Devices</span>
                   <!-- <span class="w-previos-stat">Last Day : $4,110</span> -->
                </div>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="iconic-w-wrap iconic-w-wrap">
                <span class="stat-w-title">Visitors Today</span>
                <a href="#" class="ico-cirlce-widget w_bg_green">
                    <span><i class="ico-chart"></i></span>
                </a>
                <div class="w-meta-info">
                    <span class="w-meta-value number-animate" data-value="20000" data-animation-duration="1500">0</span>
                    <span class="w-meta-title">New Visitors</span>
                   <!-- <span class="w-previos-stat">Last Day : 14,000</span> -->
                </div>
            </div>
        </div>
    </div>
<div class="row">
    <div class="col-md-12">
        <div class="w-info-graph">
            <div class="row">
                <div class="col-md-7">
                    <div class="w-info-chart">
                        <div class="w-info-chart-header">
                            <h2>Earning Graph</h2>
                            <p>
                                This is a income chart for the Matmix products
                            </p>
                        </div>


                        <div class="mini-chart-list">
                            <ul>
                                <li>
												<span class="epie-chart" data-percent="40" data-barcolor="#00acc1" data-tcolor="#e0e0e0" data-scalecolor="#e0e0e0" data-linecap="round" data-linewidth="2" data-size="80" data-animate="2000"><span class="percent"></span>
												</span>
                                    <span class="chart-sub-title">Visit</span>
                                </li>
                                <li>
												<span class="epie-chart" data-percent="35" data-barcolor="#ffb74d" data-tcolor="#e0e0e0" data-scalecolor="#e0e0e0" data-linecap="round" data-linewidth="2" data-size="80" data-animate="2000"><span class="percent"></span>
												</span>
                                    <span class="chart-sub-title">Members</span>
                                </li>
                                <li>
												<span class="epie-chart" data-percent="25" data-barcolor="#4caf50" data-tcolor="#e0e0e0" data-scalecolor="#e0e0e0" data-linecap="round" data-linewidth="2" data-size="80" data-animate="2000"><span class="percent"></span>
												</span>
                                    <span class="chart-sub-title">Sales</span>
                                </li>
                            </ul>
                        </div>

                        <div class="chart-container">
                                <div id="ocean-flot">

                                </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="w-info-chart-meta">
                        <h2>Alltime Earning</h2>
                        <span class="info-meta-value">$90,808</span>
                        <div id="ocean-flot-legend">

                        </div>
                        <span class="w-meta-title">Traffic Source</span>
                        <div class="progress-wrap">
                            <div class="clearfix progress-meta">
                                <span class="pull-left progress-label">google.com</span><span class="pull-right progress-percent label label-info"></span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar progress-bar-info" data-progress="40">
                                </div>
                            </div>
                        </div>
                        <div class="progress-wrap">
                            <div class="clearfix progress-meta">
                                <span class="pull-left progress-label">yahoo.com</span><span class="pull-right progress-percent label label-danger"></span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar progress-bar-danger" data-progress="25">
                                </div>
                            </div>
                        </div>
                        <div class="progress-wrap">
                            <div class="clearfix progress-meta">
                                <span class="pull-left progress-label">jaman.me</span><span class="pull-right progress-percent label label-primary"></span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar progress-bar-primary" data-progress="20">
                                </div>
                            </div>
                        </div>
                        <div class="progress-wrap">
                            <div class="clearfix progress-meta">
                                <span class="pull-left progress-label">envato.com</span><span class="pull-right progress-percent label label-success"></span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar progress-bar-success" data-progress="10">
                                </div>
                            </div>
                        </div>
                        <div class="progress-wrap">
                            <div class="clearfix progress-meta">
                                <span class="pull-left progress-label">Others</span><span class="pull-right progress-percent label label-warning"></span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar progress-bar-warning" data-progress="5">
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
<div class="col-md-7">
        <div class="box-widget widget-module">
            <div class="widget-head clearfix">
                <span class="h-icon"><i class="fa fa-cart-arrow-down"></i></span>
                <h4>Order Received</h4>
                <ul class="widget-action-bar pull-right">
                    <li><span class="waves-effect w-reload"><i class="fa fa-spinner"></i></span>
                    </li>
                </ul>
            </div>
            <div class="widget-container">
                <div class="table-responsive">
                    <table class="table w-order-list table-striped">
                        <thead>
                        <tr>
                            <th>
                                Order ID
                            </th>
                            <th>
                                Titile
                            </th>
                            <th>
                                Status
                            </th>
                            <th>
                                Amount
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>
                                <a href="#">#36542</a>
                            </td>
                            <td>
                                Gold
                            </td>
                            <td>
                                <span class="label label-warning">Pending</span>
                            </td>
                            <td>
                                $50/m
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="#">#38544</a>
                            </td>
                            <td>
                                Silver
                            </td>
                            <td>
                                <span class="label label-success">Confirmed</span>
                            </td>
                            <td>
                                $20/m
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="#"> #39545</a>
                            </td>
                            <td>
                                <span>Platinum</span>
                            </td>
                            <td>
                                <span class="label label-warning">Pending</span>
                            </td>
                            <td>
                                $80/m
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="#"> #39548</a>
                            </td>
                            <td>
                                <span>Platinum</span>
                            </td>
                            <td>
                                <span class="label label-warning">Pending</span>
                            </td>
                            <td>
                                $80/m
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <a href="#"> #39550</a>
                            </td>
                            <td>
                                <span>Platinum</span>
                            </td>
                            <td>
                                <span class="label label-danger">canceled</span>
                            </td>
                            <td>
                                $80/m
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<div class="col-md-5">
    <div class="box-widget widget-module">
        <div class="widget-head clearfix">
            <span class="h-icon"><i class="fa fa-users"></i></span>
            <h4>New Users</h4>
            <ul class="widget-action-bar pull-right">
                <li><span class="waves-effect w-reload"><i class="fa fa-spinner"></i></span>
                </li>
                <li><span class="widget-remove waves-effect w-remove"><i class="ico-cross"></i></span>
                </li>
            </ul>
        </div>
        <div class="widget-container">
            <div class="w-user-widget">
                <div class="w-user-list">
                    <div class="w-user-list-item">
                        <div class="w-user-thumbnail">
                            <a href="#"><img src="images/avatar/allisongrayce.jpg" alt="user">
                            </a>
                        </div>
                        <div class="w-user-info">
                            <ul>
                                <li>Name:<span><a href="#">Jean J. Thomas <span class="label label-default">Free</span></a></span>
                                </li>
                                <li>Date: <span>18th June 2015</span>
                                </li>
                                <li>Package: <span>Basic</span>
                                </li>
                            </ul>
                        </div>
                        <div class="w-user-action">
                            <a href="#" data-tooltip="tooltip" data-placement="left" title="Edit"><i class="fa fa-pencil"></i></a>
                            <a href="#" data-tooltip="tooltip" data-placement="left" title="Delete"><i class="fa fa-trash"></i></a>
                        </div>
                    </div>
                    <div class="w-user-list-item">
                        <div class="w-user-thumbnail">
                            <a href="#"><img src="images/avatar/bobbyjkane.jpg" alt="user">
                            </a>
                        </div>
                        <div class="w-user-info">
                            <ul>
                                <li>Name:<span><a href="#">Michael H. Russell <span class="label label-default">Free</span></a></span>
                                </li>
                                <li>Date: <span>18th June 2015</span>
                                </li>
                                <li>Package: <span>Basic</span>
                                </li>
                            </ul>
                        </div>
                        <div class="w-user-action">
                            <a href="#" data-tooltip="tooltip" data-placement="left" title="Edit"><i class="fa fa-pencil"></i></a>
                            <a href="#" data-tooltip="tooltip" data-placement="left" title="Delete"><i class="fa fa-trash"></i></a>
                        </div>
                    </div>
                    <div class="w-user-list-item">
                        <div class="w-user-thumbnail">
                            <a href="#"><img src="images/avatar/coreyweb.jpg" alt="user">
                            </a>
                        </div>
                        <div class="w-user-info">
                            <ul>
                                <li>Name:<span><a href="#">Tyler B. Falcon <span class="label label-success">Paid</span></a></span>
                                </li>
                                <li>Date: <span>18th June 2015</span>
                                </li>
                                <li>Package: <span>Gold</span>
                                </li>
                            </ul>
                        </div>
                        <div class="w-user-action">
                            <a href="#" data-tooltip="tooltip" data-placement="left" title="Edit"><i class="fa fa-pencil"></i></a>
                            <a href="#" data-tooltip="tooltip" data-placement="left" title="Delete"><i class="fa fa-trash"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<div class="row">
    <div class="col-md-7">
        <div class="box-widget widget-module">
            <div class="widget-head clearfix">
                <span class="h-icon"><i class="fa fa-list"></i></span>
                <h4>Activities</h4>
                <ul class="widget-action-bar pull-right">
                    <li><span class="waves-effect w-reload"><i class="fa fa-spinner"></i></span>
                    </li>
                    <li><span class="widget-remove waves-effect w-remove"><i class="ico-cross"></i></span>
                    </li>
                </ul>
            </div>
            <div class="widget-container">
                <div class="activities-timeline">
                    <ul class="activities-list">
                        <li>
                            <div class="activities-badge">
                                <span></span>
                            </div>
                            <div class="activities-details">
                                <h3 class="activities-header"><a href="#">10 Tickets Resolved</a></h3>
                                <div class="activities-meta"><i class="fa fa-clock-o"></i> 30 min ago </div>
                                <p>All are resolved</p>
                            </div>
                        </li>
                        <li>
                            <div class="activities-badge">
                                <span></span>
                            </div>
                            <div class="activities-details">
                                <h3 class="activities-header"><a href="#">New Files Added</a></h3>
                                <div class="activities-meta"><i class="fa fa-clock-o"></i> 1 hour ago </div>
                                <p>Check following files: </p>
                                <div class="attachement-list">
                                    <ul>
                                        <li>
                                            <div class="attachment-thumb">
                                                <a href="#"><i class="fa fa-file-pdf-o"></i></a>
                                            </div>
                                            <div class="attachment-info">
                                                <div class="attachment-file-name">
                                                    01-wireframe-sample.pdf
                                                </div>
                                                <div class="attachment-action-bar">
                                                    <span class="list-file-download"><a href="#"><i class="fa fa-download"></i> Download</a></span><span class="list-file-del"><a href="#"><i class="fa fa-trash"></i> Delete</a></span>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="activities-badge">
                                <span></span>
                            </div>
                            <div class="activities-details">
                                <h3 class="activities-header"><a href="#">New Post Added</a> </h3>
                                <div class="activities-meta"><i class="fa fa-clock-o"></i> July 22 at 1:12pm  </div>
                                <p>Donec porta, elit vestibulum vulputate bibendum, sem felis varius quam, eget placerat neque diam quis tortor. Suspendisse eu posuere nunc. Aliquam erat volutpat. Duis quis elit felis.</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="activities-load">
<a class="load-more" href="#">Load More</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="box-widget widget-module">
            <div class="widget-head clearfix">
                <span class="h-icon"><i class="fa fa-tasks"></i></span>
                <h4>To Do</h4>
                <ul class="widget-action-bar pull-right">
                    <li><span class="waves-effect w-reload"><i class="fa fa-spinner"></i></span>
                    </li>
                    <li><span class="widget-remove waves-effect w-remove"><i class="ico-cross"></i></span>
                    </li>
                </ul>
            </div>
            <div class="widget-container">
            <div class="todo-list">
            <div class="todo-list-item">
                <div class="todo-list-action">
                    <input type="checkbox" name="todo-select" class="todo-select">
                </div>
                <div class="todo-list-details">
                    <div class="todo-intro">
                        <h4>Send payments to all sellers </h4>
                        <div class="todo-date">
                            <label class="label label-info"> New</label>
                            <label class="label label-warning"> High</label>
                            <div class="todo-due-date">
                                <i class="fa fa-clock-o"></i>Due By: Jun 16 at 12:00 PM
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="todo-list-item">
                    <div class="todo-list-action">
                        <input type="checkbox" name="todo-select" class="todo-select">
                    </div>
                    <div class="todo-list-details">
                        <div class="todo-intro">
                            <h4>Fix jQuery $noConflict issue </h4>
                            <div class="todo-date">
                                <label class="label label-info"> New</label>
                                <label class="label label-default"> low</label>
                                <div class="todo-due-date">
                                    <i class="fa fa-clock-o"></i>Due By: Jun 16 at 12:00 PM
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="todo-list-item">
                    <div class="todo-list-action">
                        <input type="checkbox" name="todo-select" class="todo-select">
                    </div>
                    <div class="todo-list-details">
                        <div class="todo-intro">
                            <h4>Fix all database errors </h4>
                            <div class="todo-date">
                                <div class="todo-due-date">
                                    <i class="fa fa-clock-o"></i>Due By: Jun 16 at 12:00 PM
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="todo-list-item">
                    <div class="todo-list-action">
                        <input type="checkbox" name="todo-select" class="todo-select">
                    </div>
                    <div class="todo-list-details">
                        <div class="todo-intro">
                            <h4>Create a backup sever </h4>
                            <div class="todo-date">
                                <div class="todo-due-date">
                                    <i class="fa fa-clock-o"></i>Due By: Jun 16 at 12:00 PM
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="todo-list-item">
                    <div class="todo-list-action">
                        <input type="checkbox" name="todo-select" class="todo-select">
                    </div>
                    <div class="todo-list-details">
                        <div class="todo-intro">
                            <h4>Add a offloaded mysql to users </h4>
                            <div class="todo-date">
                                <div class="todo-due-date">
                                    <i class="fa fa-clock-o"></i>Due By: Jun 16 at 12:00 PM
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="todo-list-item todo-completed">
                <div class="todo-list-action">
                    <input type="checkbox" name="todo-select" class="todo-select">
                </div>
                <div class="todo-list-details">
                    <div class="todo-intro">
                        <h4>Setup git on new VPS </h4>
                        <div class="todo-date">
                            <div class="todo-due-date">
                                <i class="fa fa-clock-o"></i>Due By: Jun 16 at 12:00 PM
                            </div>
                            <div class="todo-complete-date">
                                <i class="fa fa-calendar-o"></i>Completed By: Jun 18 at 11:00 PM
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="todo-list-item todo-due">
                <div class="todo-list-action">
                    <input type="checkbox" name="todo-select" class="todo-select">
                </div>
                <div class="todo-list-details">
                    <div class="todo-intro">
                        <h4>Check load balancer</h4>
                        <div class="todo-date">
                            <label class="label label-danger"> Past Due</label>
                            <label class="label label-warning"> High</label>
                            <div class="todo-due-date">
                                <i class="fa fa-clock-o"></i>Due By: Jun 16 at 12:00 PM
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            </div>
                <div class="todo-load">
                    <a class="load-more" href="#">Load More</a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<!--Footer Start Here -->
<?php 
include('footer.php');
?>
</div>
</div>
<!--Rightbar Start Here -->
<div class="right-aside">
<div class="aside-branding">
    <div class="aside-tab">
        <ul class="nav nav-tabs pull-left">
            <li class="active"><a href="#coversetaion" data-toggle="tab" data-tooltip="tooltip" data-placement="bottom" title="Chat" class="waves-effect"><i class="fa fa-comments"></i></a>
            </li>
            <li><a href="#server-stats" data-toggle="tab" data-tooltip="tooltip" data-placement="bottom" title="Stats" class="waves-effect"><i class="fa fa-pie-chart"></i></a>
            </li>
            <li><a href="#notifications" data-toggle="tab" data-tooltip="tooltip" data-placement="bottom" title="Notifications" class="waves-effect aside-notifications"><i class="fa fa-bell"></i><span class="alert-bubble">10</span></a>
            </li>
        </ul>
    </div>
    <span class="rightbar-action waves-effect"><i class="fa fa-times"></i></span>
</div>
<div class="aside-tab-wigets">
<div class="tab-content">
<div class="tab-pane active" id="coversetaion">
    <div class="chat-search-form">
        <form>
            <input name="searchbox" value="" placeholder="Chat With" class="chat-u-search form-control">
        </form>
    </div>
    <div class="block-content chat-user-list">
        <span class="piechart"></span>
        <h3 class="clearfix"><span class="pull-left">Friends</span><span class="pull-right online-counter">3 Online</span></h3>
        <ul class="chat-list">
            <li>
                <a href="#"><span class="chat-avatar"><img src="images/avatar/adellecharles.jpg" alt="Avatar"></span><span class="chat-u-info">Adellecharles<cite>New York</cite></span></a>
                <span class="chat-u-status"><i class="fa fa-circle"></i></span>
            </li>
            <li class="chat-u-online">
                <a href="#"><span class="chat-avatar"><img src="images/avatar/allisongrayce.jpg" alt="Avatar"></span><span class="chat-u-info">Allisongrayce<cite>New York</cite></span></a>
                <span class="chat-u-status"><i class="fa fa-circle"></i></span>
            </li>
            <li class="chat-u-online">
                <a href="#"><span class="chat-avatar"><img src="images/avatar/bobbyjkane.jpg" alt="Avatar"></span><span class="chat-u-info">Bobbyjkane<cite>New York</cite></span></a>
                <span class="chat-u-status"><i class="fa fa-circle"></i></span>
            </li>
            <li class="chat-u-online">
                <a href="#"><span class="chat-avatar"><img src="images/avatar/littlenono.jpg" alt="Avatar"></span><span class="chat-u-info">Littlenono<cite>New York</cite></span></a>
                <span class="chat-u-status"><i class="fa fa-circle"></i></span>
            </li>
        </ul>
        <h3 class="clearfix"><span class="pull-left">Family</span><span class="pull-right online-counter">1 Online</span></h3>
        <ul class="chat-list">
            <li>
                <a href="#"><span class="chat-avatar"><img src="images/avatar/geeftvorm.jpg" alt="Avatar"></span><span class="chat-u-info">Geeftvorm<cite>New York</cite></span></a>
                <span class="chat-u-status"><i class="fa fa-circle"></i></span>
            </li>
            <li class="chat-u-online">
                <a href="#"><span class="chat-avatar"><img src="images/avatar/amarkdalen.jpg" alt="Avatar"></span><span class="chat-u-info">Amarkdalen<cite>New York</cite></span></a>
                <span class="chat-u-status"><i class="fa fa-circle"></i></span>
            </li>
            <li>
                <a href="#"><span class="chat-avatar"><img src="images/avatar/mko.jpg" alt="Avatar"></span><span class="chat-u-info">Mko<cite>New York</cite></span></a>
                <span class="chat-u-status"><i class="fa fa-circle"></i></span>
            </li>
            <li>
                <a href="#"><span class="chat-avatar"><img src="images/avatar/marktimemedia.jpg" alt="Avatar"></span><span class="chat-u-info">Marktimemedia<cite>New York</cite></span></a>
                <span class="chat-u-status"><i class="fa fa-circle"></i></span>
            </li>
            <li>
                <a href="#"><span class="chat-avatar"><img src="images/avatar/oykun.jpg" alt="Avatar"></span><span class="chat-u-info">Oykun<cite>New York</cite></span></a>
                <span class="chat-u-status"><i class="fa fa-circle"></i></span>
            </li>
        </ul>
    </div>
</div>
<div class="tab-pane" id="server-stats">
    <div class="block-content">
        <div class="server-stats-content">
            <h3>Work Progress</h3>
            <div class="progress-wrap">
                <div class="clearfix progress-meta">
                    <span class="pull-left progress-label">Daily Backup</span><span class="pull-right progress-percent label label-primary"></span>
                </div>
                <div class="progress">
                    <div class="progress-bar" data-progress="80">
                    </div>
                </div>
            </div>
            <div class="progress-wrap">
                <div class="clearfix progress-meta">
                    <span class="pull-left progress-label">My Sql Backup</span><span class="pull-right progress-percent label label-primary"></span>
                </div>
                <div class="progress">
                    <div class="progress-bar" data-progress="60">
                    </div>
                </div>
            </div>
            <div class="progress-wrap">
                <div class="clearfix progress-meta">
                    <span class="pull-left progress-label">Vps Configure </span><span class="pull-right progress-percent label label-primary"></span>
                </div>
                <div class="progress">
                    <div class="progress-bar" data-progress="90">
                    </div>
                </div>
            </div>
            <h3>Usage</h3>
            <div class="uasge-wrap">
                <ul>
                    <li>
                        <h4>Bandwidth</h4>
                        <span class="uasge-intro">950GB of 1.95 TB Used</span>
                    </li>
                    <li class="usage-chart">
								<span class="epie-chart" data-percent="60" data-barcolor="#e64a19" data-tcolor="#e0e0e0" data-scalecolor="#e0e0e0" data-linecap="butt" data-linewidth="3" data-size="55" data-animate="2000"><span class="percent"></span>
								</span>
                    </li>
                </ul>
            </div>
            <div class="uasge-wrap">
                <ul>
                    <li>
                        <h4>Memory </h4>
                        <span class="uasge-intro">3 GB of 6 GB Used</span>
                    </li>
                    <li class="usage-chart">
								<span class="epie-chart" data-percent="50" data-barcolor="#00acc1" data-tcolor="#e0e0e0" data-scalecolor="#e0e0e0" data-linecap="butt" data-linewidth="3" data-size="55" data-animate="2000"><span class="percent"></span>
								</span>
                    </li>
                </ul>
            </div>
            <div class="uasge-wrap">
                <ul>
                    <li>
                        <h4>HDD </h4>
                        <span class="uasge-intro">18 GB of 30 GB Used </span>
                    </li>
                    <li class="usage-chart">
								<span class="epie-chart" data-percent="60" data-barcolor="#43a047" data-tcolor="#e0e0e0" data-scalecolor="#e0e0e0" data-linecap="butt" data-linewidth="3" data-size="55" data-animate="2000"><span class="percent"></span>
								</span>
                    </li>
                </ul>
            </div>
            <h3>Used Services</h3>
            <div class="progress-wrap">
                <div class="clearfix progress-meta">
                    <span class="pull-left progress-label">Email</span><span class="pull-right progress-percent-multiple label label-primary">90%</span>
                </div>
                <div class="progress multi-progress">
                    <div class="progress-bar progress-bar-success" data-progress="40">
                    </div>
                    <div class="progress-bar progress-bar-warning progress-bar-striped" data-progress="30">
                    </div>
                    <div class="progress-bar progress-bar-danger" data-progress="20">
                    </div>
                </div>
                <span class="progress-intro">27 of 30 Email Used</span>
            </div>
            <div class="progress-wrap">
                <div class="clearfix progress-meta">
                    <span class="pull-left progress-label">Credits</span><span class="pull-right progress-percent-multiple label label-primary">70%</span>
                </div>
                <div class="progress multi-progress">
                    <div class="progress-bar progress-bar-success" data-progress="40">
                    </div>
                    <div class="progress-bar progress-bar-warning progress-bar-striped" data-progress="20">
                    </div>
                    <div class="progress-bar progress-bar-danger" data-progress="10">
                    </div>
                </div>
                <span class="progress-intro">700 of 1000 Credits Used</span>
            </div>
            <h3>Task Pending</h3>
            <div class="progress-wrap">
                <div class="clearfix progress-meta">
                    <span class="pull-left progress-label">Tickets</span><span class="pull-right progress-percent label label-primary"></span>
                </div>
                <div class="progress">
                    <div class="progress-bar" data-progress="60">
                    </div>
                </div>
                <span class="progress-intro">60 of 100 Replied / 40 Pending</span>
            </div>
            <div class="progress-wrap">
                <div class="clearfix progress-meta">
                    <span class="pull-left progress-label">Payments</span><span class="pull-right progress-percent label label-primary"></span>
                </div>
                <div class="progress">
                    <div class="progress-bar" data-progress="90">
                    </div>
                </div>
                <span class="progress-intro">90 of 100 Paid / 10 Unpaid</span>
            </div>
            <div class="progress-wrap">
                <div class="clearfix progress-meta">
                    <span class="pull-left progress-label">Review</span><span class="pull-right progress-percent label label-primary"></span>
                </div>
                <div class="progress">
                    <div class="progress-bar" data-progress="50">
                    </div>
                </div>
                <span class="progress-intro">5 of 10 Reviewed / 5 Pending</span>
            </div>
        </div>
    </div>
</div>
<div class="tab-pane" id="notifications">
    <div class="block-content">
        <div class="aside-notifications-wrap">
            <div class="message-wrap">
                <h4>You have 15 new messages</h4>
                <ul class="clearfix">
                    <li class="clearfix">
                        <a href="#" class="message-thumb"><img src="images/avatar/adellecharles.jpg" alt="image">
                        </a><a href="#" class="message-intro"><span class="message-meta">Adellecharles </span>Nunc aliquam dolor... <span class="message-time">today at 10:20 pm</span></a>
                    </li>
                    <li class="clearfix">
                        <a href="#" class="message-thumb"><img src="images/avatar/allisongrayce.jpg" alt="image">
                        </a><a href="#" class="message-intro"><span class="message-meta">Allisongrayce </span>In hac habitasse ... <span class="message-time">today at 8:29 pm</span></a>
                    </li>
                    <li class="clearfix">
                        <a href="#" class="message-thumb"><img src="images/avatar/amarkdalen.jpg" alt="image">
                        </a><a href="#" class="message-intro"><span class="message-meta">Amarkdalen </span>Suspendisse ac mauris ... <span class="message-time">yesterday at 12:29 pm</span></a>
                    </li>
                    <li class="clearfix">
                        <a href="#" class="message-thumb"><img src="images/avatar/annapickard.jpg" alt="image">
                        </a><a href="#" class="message-intro"><span class="message-meta">Annapickard </span>Vivamus lacinia facilisis... <span class="message-time">yesterday at 11:48 pm</span></a>
                    </li>
                    <li class="clearfix">
                        <a href="#" class="message-thumb"><img src="images/avatar/bobbyjkane.jpg" alt="image">
                        </a><a href="#" class="message-intro"><span class="message-meta">Bobbyjkane </span>Donec vel iaculis ... <span class="message-time">1 month ago</span></a>
                    </li>
                    <li class="clearfix">
                        <a href="#" class="message-thumb"><img src="images/avatar/chexee.jpg" alt="image">
                        </a><a href="#" class="message-intro"><span class="message-meta">Chexee </span> Curabitur eget blandit...<span class="message-time">3 months ago</span></a>
                    </li>
                    <li class="clearfix">
                        <a href="#" class="message-thumb"><img src="images/avatar/coreyweb.jpg" alt="image">
                        </a><a href="#" class="message-intro"><span class="message-meta">Coreyweb </span>Etiam molestie nulla... <span class="message-time">1 year ago</span></a>
                    </li>
                </ul>
                <a class="btn btn-primary btn-block notification-btn waves-effect clearfix" href="#"><span>View All</span></a>
            </div>
            <div class="notification-wrap">
                <h4>You have 10 new notifications</h4>
                <ul>
                    <li><a href="#" class="clearfix"><span class="ni w-green"><i class="fa fa-bullhorn"></i></span><span class="notification-message">Pellentesque semper posuere. <span class="notification-time clearfix">3 Min Ago</span></span></a>
                    </li>
                    <li><a href="#" class="clearfix"><span class="ni w-orange"><i class="fa fa-life-ring"></i></span><span class="notification-message">Nulla commodo sem at purus. <span class="notification-time clearfix">1 Hours Ago</span></span></a>
                    </li>
                    <li><a href="#" class="clearfix"><span class="ni w-bondi-blue"><i class="fa fa-star-o"></i></span><span class="notification-message">Fusce condimentum turpis. <span class="notification-time clearfix">3 Hours Ago</span></span></a>
                    </li>
                    <li><a href="#" class="clearfix"><span class="ni w-blue"><i class="fa fa-trophy"></i></span><span class="notification-message">Pellentesque habitant morbi. <span class="notification-time clearfix">Yesterday</span></span></a>
                    </li>
                    <li><a href="#" class="clearfix"><span class="ni w-brown"><i class="fa fa-bolt"></i></span><span class="notification-message">Fusce bibendum lacus mauris.<span class="notification-time clearfix">1 Month Ago</span></span></a>
                    </li>
                    <li><a href="#" class="clearfix"><span class="ni w-dark-yellow"><i class="fa fa-bookmark-o"></i></span><span class="notification-message">Donec id mi placerat, scelerisque.<span class="notification-time clearfix">3 Months Ago</span></span></a>
                    </li>
                </ul>
                <a class="btn btn-primary btn-block notification-btn clearfix waves-effect " href="#"><span>View All</span></a>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<div class="conv-container">
    <div class="conv-u-info chat-u-online">
        <ul>
            <li class="chat-avatar"><img src="images/avatar/adellecharles.jpg" alt="Avatar">
            </li>
            <li class="chat-u-info">adellecharles<span>New York</span>
            </li>
            <li><span data-tooltip="tooltip" data-placement="bottom" title="Call" class="waves-effect chat-u-call"><i class="fa fa-phone"></i></span>
            </li>
            <li><span data-tooltip="tooltip" data-placement="bottom" title="Exit" class="waves-effect chat-close"><i class="fa fa-angle-right"></i></span>
            </li>
        </ul>
    </div>
    <div class="converstaion-list">
        <div class="conversation-back">
            <div class="conv-thumb">
                <img src="images/avatar/uxceo.jpg" alt="user">
            </div>
            <div class="conv-text">
                Hello John, thank you for calling Provide Support. How may I help you?
            </div>
        </div>
        <div class="conversation-front">
            <div class="conv-text">
                Hello Mary. I understand the problem and will be happy to help you. Let’s see what I can do.
            </div>
        </div>
        <div class="conversation-front">
            <div class="conv-text">
                Let me see if I have this correct, you want me to…” or “You would like for me to…?
            </div>
        </div>
        <div class="conversation-back">
            <div class="conv-thumb">
                <img src="images/avatar/uxceo.jpg" alt="user">
            </div>
            <div class="conv-text">
                I’m not sure, but let me find out for you.
            </div>
        </div>
    </div>
    <div class="chat-input-form">
        <form>
            <input name="chatbox" value="" class="form-control chat-input">
        </form>
    </div>
</div>
</div>
<script src="js/jquery-1.11.2.min.js"></script>
<script src="js/jquery-migrate-1.2.1.min.js"></script>
<script src="js/jRespond.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/nav-accordion.js"></script>
<script src="js/hoverintent.js"></script>
<script src="js/waves.js"></script>
<script src="js/switchery.js"></script>
<script src="js/jquery.loadmask.js"></script>
<script src="js/icheck.js"></script>
<script src="js/select2.js"></script>
<script src="js/bootstrap-filestyle.js"></script>
<script src="js/bootbox.js"></script>
<script src="js/animation.js"></script>
<script src="js/colorpicker.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/sweetalert.js"></script>
<script src="js/moment.js"></script>
<script src="js/calendar/fullcalendar.js"></script>
<!--CHARTS-->
<script src="js/chart/sparkline/jquery.sparkline.js"></script>
<script src="js/chart/easypie/jquery.easypiechart.min.js"></script>
<script src="js/chart/flot/excanvas.min.js"></script>
<script src="js/chart/flot/jquery.flot.min.js"></script>
<script src="js/chart/flot/curvedLines.js"></script>
<script src="js/chart/flot/jquery.flot.time.min.js"></script>
<script src="js/chart/flot/jquery.flot.stack.min.js"></script>
<script src="js/chart/flot/jquery.flot.axislabels.js"></script>
<script src="js/chart/flot/jquery.flot.resize.min.js"></script>
<script src="js/chart/flot/jquery.flot.tooltip.min.js"></script>
<script src="js/chart/flot/jquery.flot.spline.js"></script>
<script src="js/chart/flot/jquery.flot.pie.min.js"></script>
<script src="js/chart.init.js"></script>
<script src="js/smart-resize.js"></script>
<script src="js/layout.init.js"></script>
<script src="js/matmix.init.js"></script>
<script src="js/retina.min.js"></script>
</body>

<!-- Mirrored from www.lab.westilian.com/matmix-admin/iconic-view/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 28 Sep 2017 07:48:09 GMT -->
</html>
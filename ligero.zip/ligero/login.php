<?php
include("config/connect.php");
if(isset($_POST['submit'])){
	$email=mysqli_real_escape_string($conn,$_POST['email']);
	$password=mysqli_real_escape_string($conn,$_POST['password']);
	$sqla="select * from tbl_user where userid='".$email."'";
	$querya=mysqli_query($conn,$sqla);
	if(mysqli_num_rows($querya)>0){
	$res=mysqli_fetch_assoc($querya);
	$passworda=$res['pin'];
if($password==$passworda){
	if(!empty($_POST['remember'])){
		setcookie("user",$email,time()+(10*365*24*60*60));
		setcookie("pass",$password,time()+(10*365*24*60*60));
	}
	else{
		if(isset($_COOKIE["user"])){
			setcookie("user","");
		}
		if(isset($_COOKIE["pass"])){
			setcookie("pass","");
		}
	}
	header("location:index.php");
	$_SESSION['user']=$res['id'];
}
else{
	$msg="Your pin is incorrect";
}	
	}
	else{
		$msg="We couldn't find this userid in our records";
	}
}
?>
<!doctype html>
<html>
<!-- Mirrored from www.lab.westilian.com/matmix-admin/iconic-view/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 28 Sep 2017 07:50:56 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="A Components Mix Bootstarp 3 Admin Dashboard Template">
<meta name="author" content="Westilian">
<title>Ligero Light</title>
<link rel="stylesheet" href="css/font-awesome.css" type="text/css">
<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
<link rel="stylesheet" href="css/animate.css" type="text/css">
<link rel="stylesheet" href="css/waves.css" type="text/css">
<link rel="stylesheet" href="css/layout.css" type="text/css">
<link rel="stylesheet" href="css/components.css" type="text/css">
<link rel="stylesheet" href="css/plugins.css" type="text/css">
<link rel="stylesheet" href="css/common-styles.css" type="text/css">
<link rel="stylesheet" href="css/pages.css" type="text/css">
<link rel="stylesheet" href="css/responsive.css" type="text/css">
<link rel="stylesheet" href="css/matmix-iconfont.css" type="text/css">
<link href="http://fonts.googleapis.com/css?family=Roboto:400,300,400italic,500,500italic" rel="stylesheet" type="text/css">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet" type="text/css">
</head>
<body class="login-page">
    <div class="page-container">
       
        <div class="login-container" style="margin-top:8%">
          <img src="images/logo.png" class="img-responsive">
		   <hr>
            <form class="form-signin" method="post">
                <input type="text" id="inputEmail" class="form-control floatlabel" placeholder="User-Id" name="email" value="<?php if(isset($_COOKIE['user'])){echo $_COOKIE['user'];}?>" required autofocus>
                <input type="password" id="inputPassword" class="form-control floatlabel" placeholder="Pin" name="password" value="<?php if(isset($_COOKIE['pass'])){echo $_COOKIE['pass'];}?>" required>
                <div id="remember" class="checkbox">
                    <label>
                        <input type="checkbox" class="switch-mini" name="remember" <?php if(isset($_COOKIE['user'])){ ?> checked <?php } ?>/> Remember Me
                    </label>
                </div>
                <input class="btn btn-primary btn-block btn-signin" type="submit" value="Sign In" name="submit">
            </form>
<center>
<p><?php if(isset($msg)){echo $msg;} ?></p>
</center>
            <a href="#" class="forgot-password">
                Forgot the password?
            </a>
        </div>
        <div class="create-account">
            <a href="register.php">
                Register With Us
            </a>
        </div>

        <div class="login-footer">
            Crafted with<i class="fa fa-heart"></i>by <a href="http://www.brilltechno.com">Team Brill Techno</a>

        </div>

    </div>
    <script src="js/jquery-1.11.2.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/jRespond.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/nav-accordion.js"></script>
    <script src="js/hoverintent.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/switchery.js"></script>
    <script src="js/jquery.loadmask.js"></script>
    <script src="js/icheck.js"></script>
    <script src="js/bootbox.js"></script>
    <script src="js/animation.js"></script>
    <script src="js/colorpicker.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/floatlabels.js"></script>

    <script src="js/smart-resize.js"></script>
    <script src="js/layout.init.js"></script>
    <script src="js/matmix.init.js"></script>
    <script src="js/retina.min.js"></script>
</body>


<!-- Mirrored from www.lab.westilian.com/matmix-admin/iconic-view/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 28 Sep 2017 07:50:57 GMT -->
</html>
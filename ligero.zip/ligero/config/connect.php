<?php
session_start();
$conn=new mysqli('localhost','root','','ligero') or die(mysqli_error());
?>
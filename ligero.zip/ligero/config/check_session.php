<?php
if(!isset($_SESSION['user']) or $_SESSION['user']==NULL or $_SESSION['user']=="" or empty($_SESSION['user'])){
	header("location:login.php");
}
?>
<footer class="footer-container">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <div class="footer-left">
                     <span class="footer-meta">&copy; 2017&nbsp;<a href="http://brilltechno.com">Team brilltechno</a></span>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
                <div class="footer-right">
                  <span></span>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php
$name=$_POST['id'];
if(empty($name)){
	echo "Please enter your name";
}
else{
include "config/connect.php";
$abhi="select max(id) as id from tbl_user";
$abhisar=mysqli_query($conn,$abhi) or die(mysqli_error($conn));
$abhu=mysqli_fetch_assoc($abhisar);
$idabhi=$abhu['id'];
$idabhu=$idabhi+1;
echo $name.$idabhu;
}
?>